package com.assignment.bankingapp.dto;

public class AccountRequestDto {

    private double amount;

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }
}
