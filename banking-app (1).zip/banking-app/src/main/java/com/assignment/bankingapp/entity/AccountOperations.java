package com.assignment.bankingapp.entity;

public interface AccountOperations {

    void deposit(double amount);

    void withdraw(double amount);

    void transfer(double amount, Account account);

    double getBalance();

    long getAccountNumber();
}
