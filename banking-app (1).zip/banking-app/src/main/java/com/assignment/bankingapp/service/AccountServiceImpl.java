package com.assignment.bankingapp.service;

import com.assignment.bankingapp.dto.AccountResponseDto;
import com.assignment.bankingapp.entity.Account;
import com.assignment.bankingapp.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Override
    public AccountResponseDto deposit(final long accountNumber, final double amount) {
        final Account account = findAccountByAccountNumber(accountNumber);
        account.deposit(amount);
        accountRepository.save(account);
        return buildAccountResponseDto(accountNumber, amount, account);
    }

    private Account findAccountByAccountNumber(final long accountNumber) {
        return accountRepository.findAccountByAccountNumber(accountNumber)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "No account Number exist for input"));
    }

    @Override
    public AccountResponseDto withdraw(final long accountNumber, final double amount) {
        final Account account = findAccountByAccountNumber(accountNumber);
        account.withdraw(amount);
        accountRepository.save(account);
        return buildAccountResponseDto(accountNumber, amount, account);
    }

    @Override
    public AccountResponseDto transfer(final long fromAccountNumber, final double amount, final long toAccountNumber) {
        final Account fromAccount = findAccountByAccountNumber(fromAccountNumber);
        final Account toAccount = findAccountByAccountNumber(toAccountNumber);
        fromAccount.transfer(amount, toAccount);

        accountRepository.save(fromAccount);
        accountRepository.save(toAccount);
        return buildAccountResponseDto(fromAccountNumber, amount, fromAccount);
    }

    private AccountResponseDto buildAccountResponseDto(long accountNumber, double amount, Account account) {
        AccountResponseDto accountResponseDto = new AccountResponseDto();
        accountResponseDto.setAccountNumber(accountNumber);
        accountResponseDto.setCustomerName(account.getCustomer().getFirstName() + " " + account.getCustomer().getLastName());
        accountResponseDto.setAccountBalance(account.getBalance());
        accountResponseDto.setAmountDeposited(amount);
        return accountResponseDto;
    }
}
