package com.assignment.bankingapp.repository;

public class UserRepository {
}
