package com.assignment.bankingapp.service;

import com.assignment.bankingapp.dto.CustomerRequestDto;
import com.assignment.bankingapp.dto.CustomerResponseDto;
import com.assignment.bankingapp.entity.Account;
import com.assignment.bankingapp.entity.Customer;
import com.assignment.bankingapp.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public CustomerResponseDto addCustomerToBank(final CustomerRequestDto customerRequestDto) {
        Customer customer = new Customer();
        customer.setFirstName(customerRequestDto.getFirstName());
        customer.setLastName(customerRequestDto.getLastName());
        customer.setEmail(customerRequestDto.getEmailId());
        customer.setUsername(customerRequestDto.getUsername());
        customer.setAddress(customerRequestDto.getAddress());

        Account account = new Account(new Random().nextLong(), customerRequestDto.getInitialDeposit(), customer);
        Set<Account> accounts = new HashSet<Account>();
        accounts.add(account);
        customer.setAccounts(accounts);

        customerRepository.save(customer);

        return new CustomerResponseDto(customer.getFirstName(), customer.getLastName(), account.getAccountNumber(), customer.getEmail(), customer.getUsername(), customer.getAddress());
    }



    @Override @Transactional
    public void deleteCustomer(String username) {
        customerRepository.deleteCustomerByUsername(username);

    }

    @Override
    public Customer viewCustomer(String username) {
           return customerRepository.findCustomerByUsername(username).orElseThrow(()->new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid User"));
    }


}
