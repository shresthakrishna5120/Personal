package com.assignment.bankingapp.entity;

import javax.persistence.*;

@Entity
public class Account extends BaseEntity implements AccountOperations {

    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "account_number", unique = true, nullable = false)
    private long accountNumber;

    @ManyToOne
    private Customer customer;

    private double balance = 0;

    public Account() {}

    public Account(final long accountNumber, final double balance, final Customer customer){
        this.accountNumber = accountNumber;
        this.customer = customer;
        if (balance >= 0) {
            this.balance = balance;
        }
        else {
            this.balance = 0;
        }
    }

    public void withdraw(final double amount){
        if (amount > getBalance()) {
            throw new RuntimeException("Insufficient Funds");
        } else {
            setBalance(getBalance() - amount);
        }
    }

    public void deposit(final double amount){
        balance += amount;
    }

    public void transfer(final double amount, final Account account) {
        if (amount > getBalance()) {
            throw new RuntimeException("Insufficient Funds");
        } else {
            account.setBalance(amount);
            setBalance(getBalance() - amount);
        }
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
