package com.assignment.bankingapp.repository;

import com.assignment.bankingapp.entity.Customer;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
    void deleteCustomerByUsername(String userName);

    Optional<Customer> findCustomerByUsername(String username);
}
