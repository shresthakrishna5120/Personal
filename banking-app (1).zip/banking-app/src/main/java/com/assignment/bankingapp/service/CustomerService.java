package com.assignment.bankingapp.service;

import com.assignment.bankingapp.dto.CustomerRequestDto;
import com.assignment.bankingapp.dto.CustomerResponseDto;
import com.assignment.bankingapp.entity.Customer;

public interface CustomerService {

    CustomerResponseDto addCustomerToBank(CustomerRequestDto customerRequestDto);

    void deleteCustomer(String username);

    Customer viewCustomer(String username);


}
