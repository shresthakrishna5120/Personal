package com.assignment.bankingapp.service;

import com.assignment.bankingapp.dto.AccountResponseDto;

public interface AccountService {

    AccountResponseDto deposit(long accountNumber, double amount);

    AccountResponseDto withdraw(long accountNumber, double amount);

    AccountResponseDto transfer(long fromAccountNumber, double amount, long toAccountNumber);
}
