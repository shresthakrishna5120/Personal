package com.assignment.bankingapp.controller;

import com.assignment.bankingapp.dto.AccountRequestDto;
import com.assignment.bankingapp.dto.AccountResponseDto;
import com.assignment.bankingapp.dto.CustomerResponseDto;
import com.assignment.bankingapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("deposit/accountNumber/{accountNumber}")
    public ResponseEntity<AccountResponseDto> deposit(@PathVariable final long accountNumber, @RequestBody AccountRequestDto accountRequestDto) {
        return new ResponseEntity(accountService.deposit(accountNumber, accountRequestDto.getAmount()), HttpStatus.OK);
    }


    @PostMapping("withdraw/accountNumber/{accountNumber}")
    public ResponseEntity<AccountResponseDto> withdraw(@PathVariable final long accountNumber, @RequestBody AccountRequestDto accountRequestDto) {
        return new ResponseEntity(accountService.withdraw(accountNumber, accountRequestDto.getAmount()), HttpStatus.OK);
    }

    @PostMapping("transfer/fromAccountNumber/{fromAccountNumber}/toAccountNumber/{toAccountNumber}")
    public ResponseEntity<AccountResponseDto> transfer(@PathVariable final long fromAccountNumber, @PathVariable final long toAccountNumber, @RequestBody AccountRequestDto accountRequestDto) {
        return new ResponseEntity(accountService.transfer(fromAccountNumber, accountRequestDto.getAmount(), toAccountNumber), HttpStatus.OK);
    }

}
