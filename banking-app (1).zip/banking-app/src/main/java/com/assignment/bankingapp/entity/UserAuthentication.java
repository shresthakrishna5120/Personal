/*
package com.assignment.bankingapp.entity;

import javax.persistence.Entity;

@Entity
public class UserAuthentication extends BaseEntity {

    private String username;

    private String password;

    private User user;
}
*/
