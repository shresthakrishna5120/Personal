package com.assignment.bankingapp.controller;

import com.assignment.bankingapp.dto.CustomerResponseDto;
import com.assignment.bankingapp.dto.CustomerRequestDto;
import com.assignment.bankingapp.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("customer")
public class BankController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/get")
    public String getSome() {
        return "Hello";
    }

    @PostMapping
    public ResponseEntity<CustomerResponseDto> addCustomerToBank(@RequestBody final CustomerRequestDto customerRequestDto) {
        //CustomerResponseDto customerResponseDto = customerService.addCustomerToBank(customerRequestDto);
        return new ResponseEntity(customerService.addCustomerToBank(customerRequestDto), HttpStatus.CREATED);
    }

    @DeleteMapping("/{username}")
    public HttpStatus removeCustomerFromBank (@PathVariable("username") String username) {
        customerService.deleteCustomer(username);
        return HttpStatus.OK;
    }


    @GetMapping("/{username}")
    public ResponseEntity<CustomerResponseDto> getCustomer (@PathVariable("username") String username) {
      return new ResponseEntity(customerService.viewCustomer(username), HttpStatus.OK);
    }
}
