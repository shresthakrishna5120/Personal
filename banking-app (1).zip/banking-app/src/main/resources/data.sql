insert into user (name) values ('bob');
--insert into role (username, authority) values ('bob', 'ROLE_USER');

insert into user (name) values ('sara');
--insert into roles (username, authority) values ('sara', 'ROLE_ADMIN');