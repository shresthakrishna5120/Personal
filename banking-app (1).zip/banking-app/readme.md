Spring Boot with H2 DB and Spring Security to secure rest API

Rest API is secured using In-Memory DB
So only 1 user with (user/Test1234) credentials is allowed to consume REST API.

